# Project Statement

**Submitted by:** Ina Robinson (24BEC10042)

## Problem Statement
Manual tracking of library books, members and issue/return activity can be time-consuming and error-prone. A small academic institution or class library needs a simple application to maintain book and member details, along with issue and return activity, in an organized way.

## Scope
The project provides a command-line system for maintaining library records. It supports creation, retrieval, search, issue/return tracking, deletion, validation and local persistence. The current version is intended as an academic prototype rather than a production library information system.

## Target Users
- Students learning Java and object-oriented programming
- Librarians or faculty managing a small collection of books
- Small academic/project demonstrations

## High-Level Features
1. Book record management
2. Member record management (Student / Faculty)
3. Book search and retrieval
4. Issue and return tracking
5. Validation and exception handling
6. Local file-based persistence
7. Modular Java architecture
