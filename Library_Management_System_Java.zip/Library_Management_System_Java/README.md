# Library Management System in Java

**Author:** Ina Robinson
**Roll No:** 24BEC10042

## 1. Project Overview
A console-based Library Management System developed using core Java and object-oriented programming. It manages books and members, tracks book issue/return activity, validates input, handles exceptions, and stores records locally.

## 2. Features
- Add book records
- View all books (sorted by title)
- Search a book by ISBN
- Add members (Student or Faculty)
- Issue a book to a member
- Return a book from a member
- Delete a book record
- Save and load data using file I/O
- Input validation and exception handling

## 3. Technologies
- Java 17 or later
- OOP: abstraction, inheritance, encapsulation and polymorphism
- Collections: ArrayList, LinkedHashMap
- Exception handling
- File I/O and serialization streams
- Java Stream API
- Git/GitHub for version control

## 4. Project Structure
```text
Library_Management_System_Java/
├── src/
│   ├── Main.java
│   ├── Member.java
│   ├── Student.java
│   ├── Faculty.java
│   ├── Book.java
│   ├── IssueRecord.java
│   ├── Validatable.java
│   ├── ValidationException.java
│   ├── LibraryRepository.java
│   └── LibraryService.java
├── README.md
├── statement.md
└── report.md
```

## 5. How to Run
Open a terminal in the `src` directory.

```bash
javac *.java
java Main
```

Java 17+ is recommended because the program uses modern switch syntax.

## 6. Testing
Test the following:
1. Add a valid book.
2. Attempt a duplicate ISBN.
3. Search for an existing and non-existing ISBN.
4. Add a Student member and a Faculty member.
5. Issue a book to a member, then try issuing the last copy twice.
6. Return an issued book.
7. Delete an existing book.
8. Save and restart the program to verify stored records.

## 7. Academic Concepts Demonstrated
- Classes and objects
- Constructors
- Access modifiers
- `this`
- `final`
- Abstract class
- Inheritance
- Method overriding
- Interface
- Polymorphism
- Exception handling
- Collections
- File handling
- Stream API
- Modular design
