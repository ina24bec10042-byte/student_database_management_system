# Project Report — Library Management System in Java

**Name:** Ina Robinson
**Roll No:** 24BEC10042

## 1. Introduction
This report describes a console-based Library Management System built in core Java. The system was designed as an academic mini-project to demonstrate object-oriented programming principles alongside practical features such as file persistence and stream-based data processing.

## 2. Objective
To design and implement a simple, modular Java application that lets a librarian:
- maintain a catalog of books,
- register members (students and faculty),
- issue and return books,
- and persist all of this data between program runs.

## 3. System Design
The system follows a layered structure:
- **Model layer** — `Book`, `Member` (abstract), `Student`, `Faculty`, and `IssueRecord` represent the core data.
- **Repository layer** — `LibraryRepository` is responsible only for storing data in memory and persisting it to disk using Java object serialization.
- **Service layer** — `LibraryService` contains the business rules (validation before adding a book/member, checking availability before issuing a book, matching an active issue record before a return).
- **Presentation layer** — `Main` provides a text menu that reads user input and calls into the service layer.

This separation keeps each class focused on a single responsibility, which is one of the object-oriented design principles emphasized in the coursework.

## 4. Object-Oriented Concepts Used
- **Abstraction & Inheritance:** `Member` is an abstract class; `Student` and `Faculty` extend it and each supplies its own `getRole()` implementation.
- **Polymorphism:** Members are handled through the shared `Member` reference type, while `toString()` and `getRole()` behave differently for each subclass.
- **Encapsulation:** All fields are private/protected with controlled access through getters.
- **Interfaces:** `Validatable` defines a `validate()` contract implemented by `Book`, `Student`, and `Faculty`.
- **Exception Handling:** A custom checked exception, `ValidationException`, is thrown for invalid input and caught at the menu layer so the program never crashes on bad data.
- **Collections & Streams:** Books and members are stored in `LinkedHashMap`s for fast lookup by key; the Stream API is used to sort books by title and to count available titles.
- **File I/O:** `ObjectOutputStream`/`ObjectInputStream` are used to serialize and deserialize books, members, and issue records to local `.dat` files.

## 5. Sample Workflow
1. Add a book (e.g., ISBN `978-0134685991`, "Effective Java").
2. Add a member (e.g., a Student named Ina Robinson).
3. Issue the book to that member — the available copy count decreases by one.
4. Return the book — the available copy count is restored and the issue record is marked returned.
5. Save data — all three `.dat` files are written to disk so the state survives a restart.

## 6. Conclusion
The project demonstrates a practical, modular approach to building a small data-management application in Java. It reinforces core OOP concepts, exception handling, collections, the Stream API, and file-based persistence, and can be extended further with features such as due-date tracking, fines, or a graphical interface.
