import java.io.Serializable;

public abstract class Member implements Serializable {
    protected int id;
    protected String name;
    protected String email;

    public Member(int id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }

    public abstract String getRole();

    @Override
    public String toString() {
        return id + " | " + name + " | " + email + " | " + getRole();
    }
}
