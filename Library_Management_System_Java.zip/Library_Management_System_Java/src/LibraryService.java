import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class LibraryService {
    private final LibraryRepository repository;

    public LibraryService(LibraryRepository repository) {
        this.repository = repository;
    }

    public void addBook(Book book) throws ValidationException {
        book.validate();
        if (repository.findBook(book.getIsbn()) != null) {
            throw new ValidationException("A book with this ISBN already exists.");
        }
        repository.addBook(book);
    }

    public void addMember(Member member) throws ValidationException {
        if (member instanceof Validatable validatable) {
            validatable.validate();
        }
        if (repository.findMember(member.getId()) != null) {
            throw new ValidationException("A member with this ID already exists.");
        }
        repository.addMember(member);
    }

    public Book searchBook(String isbn) {
        return repository.findBook(isbn);
    }

    public boolean deleteBook(String isbn) {
        return repository.deleteBook(isbn);
    }

    public void issueBook(String isbn, int memberId) throws ValidationException {
        Book book = repository.findBook(isbn);
        if (book == null) {
            throw new ValidationException("No book found with ISBN " + isbn);
        }
        if (repository.findMember(memberId) == null) {
            throw new ValidationException("No member found with ID " + memberId);
        }
        if (!book.issueCopy()) {
            throw new ValidationException("No copies of this book are currently available.");
        }
        repository.addIssueRecord(new IssueRecord(isbn, memberId, LocalDate.now()));
    }

    public void returnBook(String isbn, int memberId) throws ValidationException {
        Book book = repository.findBook(isbn);
        if (book == null) {
            throw new ValidationException("No book found with ISBN " + isbn);
        }
        List<IssueRecord> matches = repository.getIssueRecords().stream()
                .filter(r -> r.getIsbn().equals(isbn) && r.getMemberId() == memberId && !r.isReturned())
                .collect(Collectors.toList());
        if (matches.isEmpty()) {
            throw new ValidationException("No active issue record found for this book and member.");
        }
        matches.get(0).markReturned(LocalDate.now());
        book.returnCopy();
    }

    public long countAvailableBooks() {
        return repository.getAllBooks().stream()
                .filter(b -> b.getAvailableCopies() > 0)
                .count();
    }

    public List<Book> booksSortedByTitle() {
        return repository.getAllBooks().stream()
                .sorted(Comparator.comparing(Book::getTitle, String.CASE_INSENSITIVE_ORDER))
                .collect(Collectors.toList());
    }

    public LibraryRepository getRepository() {
        return repository;
    }
}
