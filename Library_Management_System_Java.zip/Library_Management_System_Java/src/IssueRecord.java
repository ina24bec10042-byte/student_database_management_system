import java.io.Serializable;
import java.time.LocalDate;

public class IssueRecord implements Serializable {
    private final String isbn;
    private final int memberId;
    private final LocalDate issueDate;
    private LocalDate returnDate;

    public IssueRecord(String isbn, int memberId, LocalDate issueDate) {
        this.isbn = isbn;
        this.memberId = memberId;
        this.issueDate = issueDate;
    }

    public String getIsbn() { return isbn; }
    public int getMemberId() { return memberId; }
    public LocalDate getIssueDate() { return issueDate; }
    public LocalDate getReturnDate() { return returnDate; }
    public boolean isReturned() { return returnDate != null; }

    public void markReturned(LocalDate date) {
        this.returnDate = date;
    }

    @Override
    public String toString() {
        String status = isReturned() ? "Returned on " + returnDate : "Not returned";
        return "ISBN " + isbn + " -> Member " + memberId + " | Issued: " + issueDate + " | " + status;
    }
}
