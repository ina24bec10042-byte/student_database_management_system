import java.io.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class LibraryRepository {
    private static final String BOOKS_FILE = "books.dat";
    private static final String MEMBERS_FILE = "members.dat";
    private static final String RECORDS_FILE = "records.dat";

    private final Map<String, Book> books = new LinkedHashMap<>();
    private final Map<Integer, Member> members = new LinkedHashMap<>();
    private final List<IssueRecord> issueRecords = new ArrayList<>();

    public void addBook(Book book) { books.put(book.getIsbn(), book); }
    public Book findBook(String isbn) { return books.get(isbn); }
    public boolean deleteBook(String isbn) { return books.remove(isbn) != null; }
    public Collection<Book> getAllBooks() { return books.values(); }

    public void addMember(Member member) { members.put(member.getId(), member); }
    public Member findMember(int id) { return members.get(id); }
    public Collection<Member> getAllMembers() { return members.values(); }

    public void addIssueRecord(IssueRecord record) { issueRecords.add(record); }
    public List<IssueRecord> getIssueRecords() { return issueRecords; }

    @SuppressWarnings("unchecked")
    public void loadAll() {
        loadMap(BOOKS_FILE, (Map<String, Book>) (Map<?, ?>) books);
        loadMap(MEMBERS_FILE, (Map<Integer, Member>) (Map<?, ?>) members);
        loadList(RECORDS_FILE, issueRecords);
    }

    public void saveAll() {
        saveObject(BOOKS_FILE, new LinkedHashMap<>(books));
        saveObject(MEMBERS_FILE, new LinkedHashMap<>(members));
        saveObject(RECORDS_FILE, new ArrayList<>(issueRecords));
    }

    private void saveObject(String file, Object obj) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(file))) {
            out.writeObject(obj);
        } catch (IOException e) {
            System.out.println("Could not save " + file + ": " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private <K, V> void loadMap(String file, Map<K, V> target) {
        File f = new File(file);
        if (!f.exists()) return;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            target.putAll((Map<K, V>) in.readObject());
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not load " + file + ": " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private <T> void loadList(String file, List<T> target) {
        File f = new File(file);
        if (!f.exists()) return;
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(f))) {
            target.addAll((List<T>) in.readObject());
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Could not load " + file + ": " + e.getMessage());
        }
    }
}
