import java.io.Serializable;

public class Book implements Validatable, Serializable {
    private final String isbn;
    private String title;
    private String author;
    private String category;
    private int totalCopies;
    private int availableCopies;

    public Book(String isbn, String title, String author, String category, int totalCopies) {
        this.isbn = isbn;
        this.title = title;
        this.author = author;
        this.category = category;
        this.totalCopies = totalCopies;
        this.availableCopies = totalCopies;
    }

    public String getIsbn() { return isbn; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getCategory() { return category; }
    public int getTotalCopies() { return totalCopies; }
    public int getAvailableCopies() { return availableCopies; }

    public boolean issueCopy() {
        if (availableCopies <= 0) return false;
        availableCopies--;
        return true;
    }

    public boolean returnCopy() {
        if (availableCopies >= totalCopies) return false;
        availableCopies++;
        return true;
    }

    @Override
    public void validate() throws ValidationException {
        if (isbn == null || isbn.isBlank()) {
            throw new ValidationException("ISBN cannot be empty.");
        }
        if (title == null || title.isBlank()) {
            throw new ValidationException("Title cannot be empty.");
        }
        if (totalCopies < 0) {
            throw new ValidationException("Total copies cannot be negative.");
        }
    }

    @Override
    public String toString() {
        return isbn + " | " + title + " | " + author + " | Category: " + category
                + " | Available: " + availableCopies + "/" + totalCopies;
    }
}
