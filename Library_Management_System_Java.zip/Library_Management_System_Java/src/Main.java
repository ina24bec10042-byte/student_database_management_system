import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        LibraryRepository repository = new LibraryRepository();
        repository.loadAll();
        LibraryService service = new LibraryService(repository);
        Scanner scanner = new Scanner(System.in);

        boolean running = true;
        while (running) {
            printMenu();
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1" -> addBook(scanner, service);
                case "2" -> viewAllBooks(service);
                case "3" -> searchBook(scanner, service);
                case "4" -> addMember(scanner, service);
                case "5" -> issueBook(scanner, service);
                case "6" -> returnBook(scanner, service);
                case "7" -> deleteBook(scanner, service);
                case "8" -> {
                    repository.saveAll();
                    System.out.println("Data saved successfully.");
                }
                case "9" -> {
                    repository.saveAll();
                    System.out.println("Data saved successfully.\nProgram closed.");
                    running = false;
                }
                default -> System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    private static void printMenu() {
        System.out.println("\n=== LIBRARY MANAGEMENT SYSTEM ===");
        System.out.println("1. Add Book");
        System.out.println("2. View All Books");
        System.out.println("3. Search Book by ISBN");
        System.out.println("4. Add Member");
        System.out.println("5. Issue Book");
        System.out.println("6. Return Book");
        System.out.println("7. Delete Book");
        System.out.println("8. Save Data");
        System.out.println("9. Exit");
        System.out.print("Choose: ");
    }

    private static void addBook(Scanner scanner, LibraryService service) {
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        System.out.print("Title: ");
        String title = scanner.nextLine().trim();
        System.out.print("Author: ");
        String author = scanner.nextLine().trim();
        System.out.print("Category: ");
        String category = scanner.nextLine().trim();
        System.out.print("Total copies: ");
        int copies;
        try {
            copies = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number for copies.");
            return;
        }
        try {
            service.addBook(new Book(isbn, title, author, category, copies));
            System.out.println("Book added successfully.");
        } catch (ValidationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void viewAllBooks(LibraryService service) {
        List<Book> books = service.booksSortedByTitle();
        if (books.isEmpty()) {
            System.out.println("No books in the library yet.");
            return;
        }
        books.forEach(System.out::println);
        System.out.println("Available titles: " + service.countAvailableBooks());
    }

    private static void searchBook(Scanner scanner, LibraryService service) {
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        Book book = service.searchBook(isbn);
        System.out.println(book != null ? book : "No book found with that ISBN.");
    }

    private static void addMember(Scanner scanner, LibraryService service) {
        System.out.print("Member ID: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid member ID.");
            return;
        }
        System.out.print("Name: ");
        String name = scanner.nextLine().trim();
        System.out.print("Email: ");
        String email = scanner.nextLine().trim();
        System.out.print("Type (1-Student, 2-Faculty): ");
        String type = scanner.nextLine().trim();
        try {
            Member member;
            if (type.equals("2")) {
                System.out.print("Department: ");
                member = new Faculty(id, name, email, scanner.nextLine().trim());
            } else {
                System.out.print("Course: ");
                member = new Student(id, name, email, scanner.nextLine().trim());
            }
            service.addMember(member);
            System.out.println("Member added successfully.");
        } catch (ValidationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void issueBook(Scanner scanner, LibraryService service) {
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        System.out.print("Member ID: ");
        int memberId;
        try {
            memberId = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid member ID.");
            return;
        }
        try {
            service.issueBook(isbn, memberId);
            System.out.println("Book issued successfully.");
        } catch (ValidationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void returnBook(Scanner scanner, LibraryService service) {
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        System.out.print("Member ID: ");
        int memberId;
        try {
            memberId = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid member ID.");
            return;
        }
        try {
            service.returnBook(isbn, memberId);
            System.out.println("Book returned successfully.");
        } catch (ValidationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void deleteBook(Scanner scanner, LibraryService service) {
        System.out.print("ISBN: ");
        String isbn = scanner.nextLine().trim();
        if (service.deleteBook(isbn)) {
            System.out.println("Book deleted successfully.");
        } else {
            System.out.println("No book found with that ISBN.");
        }
    }
}
