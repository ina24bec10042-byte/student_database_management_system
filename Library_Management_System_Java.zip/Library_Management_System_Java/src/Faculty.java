public class Faculty extends Member implements Validatable {
    private final String department;

    public Faculty(int id, String name, String email, String department) {
        super(id, name, email);
        this.department = department;
    }

    public String getDepartment() { return department; }

    @Override
    public String getRole() { return "Faculty"; }

    @Override
    public void validate() throws ValidationException {
        if (name == null || name.isBlank()) {
            throw new ValidationException("Faculty name cannot be empty.");
        }
        if (email == null || !email.contains("@")) {
            throw new ValidationException("Invalid email address.");
        }
        if (department == null || department.isBlank()) {
            throw new ValidationException("Department cannot be empty.");
        }
    }

    @Override
    public String toString() {
        return super.toString() + " | Department: " + department;
    }
}
