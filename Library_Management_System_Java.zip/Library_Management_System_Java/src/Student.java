public class Student extends Member implements Validatable {
    private final String course;

    public Student(int id, String name, String email, String course) {
        super(id, name, email);
        this.course = course;
    }

    public String getCourse() { return course; }

    @Override
    public String getRole() { return "Student"; }

    @Override
    public void validate() throws ValidationException {
        if (name == null || name.isBlank()) {
            throw new ValidationException("Student name cannot be empty.");
        }
        if (email == null || !email.contains("@")) {
            throw new ValidationException("Invalid email address.");
        }
        if (course == null || course.isBlank()) {
            throw new ValidationException("Course cannot be empty.");
        }
    }

    @Override
    public String toString() {
        return super.toString() + " | Course: " + course;
    }
}
